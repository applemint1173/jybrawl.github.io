$(function () {

    $('#mobile-menu-icon').on('click', function () {
        $('#head ul').toggleClass('mobile-active');
        if ($('#head ul').hasClass('mobile-active')) {
            $('#mobile-menu-icon span').css('background-color', 'white');
        } else {
            $('#mobile-menu-icon span').css('background-color', 'black');
        }
    });
    // 새로고침 버그 끝맺음에 방지
    $(window).trigger('scroll');
    // 새로고침 윈도우 너비 초기화
    var initialWidth = $(window).width();
    $(window).on('resize', function () {
        var newWidth = $(window).width();
        if (newWidth !== initialWidth) {
            location.reload();
        }
    });
});